# Benessere Streamlit

Landing page en Streamlit para Benessere Açai sin azúcar.

## Archivos
- `app.py` — app principal
- `requirements.txt` — dependencias
- `logo.png` — logo (se puede reemplazar por el tuyo)

## Correr localmente
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Desplegar en Streamlit Cloud
1. Sube esta carpeta a un repositorio público en GitHub.
2. Ve a https://share.streamlit.io
3. Conecta tu GitHub y elige el repo + archivo `app.py`.
4. Haz Deploy 🚀
